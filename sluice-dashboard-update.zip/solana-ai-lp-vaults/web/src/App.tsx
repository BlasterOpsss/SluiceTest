import { useCallback, useEffect, useRef, useState } from "react";
import { useConnection, useWallet } from "@solana/wallet-adapter-react";
import { WalletMultiButton } from "@solana/wallet-adapter-react-ui";
import { PublicKey, Transaction, TransactionInstruction } from "@solana/web3.js";
import { getMint } from "@solana/spl-token";
import * as V from "./vault";
import Dashboard, { type BalanceView, type VaultView } from "./Dashboard";
import { Badge, Toasts, type ToastItem } from "./ui";
import { clusterOf, explorerUrl, parseUnits } from "./format";

const REFRESH_MS = 15_000;

export default function App() {
  const { connection } = useConnection();
  const { publicKey, sendTransaction } = useWallet();
  const rpcUrl = connection.rpcEndpoint;
  const cluster = clusterOf(rpcUrl);

  const [vault, setVault] = useState<VaultView | null>(null);
  const [balances, setBalances] = useState<BalanceView[]>([]);
  const [loaded, setLoaded] = useState(false);
  const [busy, setBusy] = useState(false);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const nextId = useRef(1);

  const push = useCallback((t: Omit<ToastItem, "id">, ttl = 0) => {
    const id = nextId.current++;
    setToasts((x) => [...x.filter((y) => y.kind !== "info"), { ...t, id }]);
    if (ttl) setTimeout(() => setToasts((x) => x.filter((y) => y.id !== id)), ttl);
    return id;
  }, []);
  const dismiss = (id: number) => setToasts((x) => x.filter((y) => y.id !== id));

  const refresh = useCallback(async () => {
    if (!publicKey || !V.PROGRAM_CONFIGURED) return;
    const v = await V.fetchVault(connection, publicKey);
    if (v) {
      setVault({ address: v.address.toBase58(), agent: v.agent?.toBase58() ?? null, guardrails: v.guardrails });
      setBalances(await V.fetchBalances(connection, v.address));
    } else {
      setVault(null);
      setBalances([]);
    }
    setLoaded(true);
  }, [connection, publicKey]);

  useEffect(() => {
    setLoaded(false);
    setVault(null);
    const go = () => refresh().catch((e) => push({ kind: "err", text: `Refresh failed: ${e instanceof Error ? e.message : String(e)}` }, 6000));
    go();
    const t = setInterval(go, REFRESH_MS);
    return () => clearInterval(t);
  }, [refresh, push]);

  async function run(label: string, build: () => Promise<TransactionInstruction>) {
    if (!publicKey) return;
    setBusy(true);
    const pending = push({ kind: "info", text: `${label} — approve in your wallet…` });
    try {
      const tx = new Transaction().add(await build());
      const sig = await sendTransaction(tx, connection);
      dismiss(pending);
      push({ kind: "info", text: `${label} — confirming…`, href: explorerUrl("tx", sig, rpcUrl) });
      await connection.confirmTransaction(sig, "confirmed");
      push({ kind: "ok", text: `${label} succeeded`, href: explorerUrl("tx", sig, rpcUrl) }, 8000);
      await refresh();
    } catch (e) {
      dismiss(pending);
      push({ kind: "err", text: `${label} failed: ${e instanceof Error ? e.message : String(e)}` }, 10000);
    } finally {
      setBusy(false);
    }
  }

  async function units(mintStr: string, amountStr: string) {
    const mint = new PublicKey(mintStr);
    const { decimals } = await getMint(connection, mint);
    const amount = parseUnits(amountStr, decimals);
    if (amount === null || amount <= 0n) throw new Error(`Amount must be positive with at most ${decimals} decimals`);
    return { mint, amount };
  }

  return (
    <main>
      <header>
        <div className="brand">
          <span className="logo" aria-hidden>◈</span>
          <div><h1>Sluice</h1><small>AI-managed LP vaults</small></div>
        </div>
        <div className="head-right">
          <Badge tone={cluster === "mainnet" ? "bad" : "mute"}>{cluster}</Badge>
          <WalletMultiButton />
        </div>
      </header>

      <div className="banner warn">Pre-alpha and unaudited. Only use funds you can afford to lose.</div>

      {!V.PROGRAM_CONFIGURED && (
        <div className="banner err">Set <code>VITE_PROGRAM_ID</code> in <code>web/.env</code> (see <code>.env.example</code>), then restart the dev server.</div>
      )}

      {!publicKey && (
        <section className="hero">
          <h2>Let an agent work your liquidity — never your keys.</h2>
          <ul className="points">
            <li><b>Non-custodial.</b> Funds sit in a vault you own; only you can withdraw, only to your wallet.</li>
            <li><b>Guard-railed.</b> Set position size, slippage, stop-loss and a daily action cap on-chain.</li>
            <li><b>Instant kill switch.</b> Pause or revoke the agent in one transaction.</li>
          </ul>
          <p className="mute">Connect a wallet to get started.</p>
        </section>
      )}

      {publicKey && V.PROGRAM_CONFIGURED && !loaded && <p className="mute center">Loading vault…</p>}

      {publicKey && V.PROGRAM_CONFIGURED && loaded && !vault && (
        <section className="hero">
          <h2>Create your vault</h2>
          <p className="mute">One transaction creates your personal vault and default guardrails. You can change everything afterwards.</p>
          <button disabled={busy} onClick={() => run("Create vault", () => V.ixInitialize(publicKey))}>Create vault</button>
        </section>
      )}

      {publicKey && vault && (
        <Dashboard
          rpcUrl={rpcUrl}
          vault={vault}
          balances={balances}
          busy={busy}
          onDeposit={(m, a) => run("Deposit", async () => { const u = await units(m, a); return V.ixDeposit(publicKey, u.mint, u.amount); })}
          onWithdraw={(m, a) => run("Withdraw", async () => { const u = await units(m, a); return V.ixWithdraw(publicKey, u.mint, u.amount); })}
          onSetAgent={(a) => run("Set agent", () => V.ixSetAgent(publicKey, new PublicKey(a)))}
          onRevoke={() => run("Revoke agent", () => V.ixRevokeAgent(publicKey))}
          onSaveGuardrails={(g) => run(g.paused !== vault.guardrails.paused && g.paused ? "Pause vault" : "Save guardrails", () => V.ixSetGuardrails(publicKey, g))}
        />
      )}

      <Toasts items={toasts} onClose={dismiss} />
    </main>
  );
}

import { useEffect, useState } from "react";
import {
  GUARDRAIL_FIELDS, KNOWN_TOKENS, bpsToPct, explorerUrl, isPubkeyLike, parseUnits, shortAddr, symbolFor,
  validateGuardrails, type GuardrailValues,
} from "./format";
import { Addr, Badge, Field, Section, Stat } from "./ui";

export interface VaultView {
  address: string;
  agent: string | null;
  guardrails: GuardrailValues & { actionsToday: number };
}
export interface BalanceView { mint: string; amount: string }

export interface DashboardProps {
  rpcUrl: string;
  vault: VaultView;
  balances: BalanceView[];
  busy: boolean;
  onDeposit: (mint: string, amount: string) => void;
  onWithdraw: (mint: string, amount: string) => void;
  onSetAgent: (agent: string) => void;
  onRevoke: () => void;
  onSaveGuardrails: (g: GuardrailValues) => void;
}

const strip = ({ actionsToday: _a, ...g }: VaultView["guardrails"]): GuardrailValues => g;

export default function Dashboard(p: DashboardProps) {
  const { vault, balances, busy, rpcUrl } = p;
  const saved = strip(vault.guardrails);
  const { paused, dailyActionCap, actionsToday } = vault.guardrails;

  // --- guardrail draft: only resync from chain when the user has no unsaved edits
  const [draft, setDraft] = useState<GuardrailValues>(saved);
  const savedKey = JSON.stringify(saved);
  const dirty = JSON.stringify(draft) !== savedKey;
  useEffect(() => { if (!dirty) setDraft(saved); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [savedKey]);
  const errs = validateGuardrails(draft);
  const invalid = Object.keys(errs).length > 0;

  // --- funds form
  const [mint, setMint] = useState("");
  const [amount, setAmount] = useState("");
  const held = balances.find((b) => b.mint === mint.trim());
  const amountOk = parseUnits(amount, 18) !== null && Number(amount) > 0;
  const mintOk = isPubkeyLike(mint);

  // --- agent form
  const [agentStr, setAgentStr] = useState("");
  const agentOk = isPubkeyLike(agentStr);
  const [confirmRevoke, setConfirmRevoke] = useState(false);

  const status = paused ? { tone: "warn" as const, text: "Paused" }
    : vault.agent ? { tone: "ok" as const, text: "Agent active" }
    : { tone: "mute" as const, text: "No agent" };

  return (
    <>
      {paused && (
        <div className="banner warn">
          <strong>Vault is paused.</strong> The agent cannot act until you unpause in Guardrails.
        </div>
      )}

      <div className="stats">
        <Stat label="Status" value={<Badge tone={status.tone}>{status.text}</Badge>} />
        <Stat label="Agent actions today" value={`${actionsToday} / ${dailyActionCap}`}
          sub={<span className="bar"><i style={{ width: `${Math.min(100, (actionsToday / Math.max(1, dailyActionCap)) * 100)}%` }} /></span>} />
        <Stat label="Max position" value={bpsToPct(saved.maxPositionBps)} sub="of vault per position" />
        <Stat label="Stop-loss" value={bpsToPct(saved.stopLossBps)} sub={`slippage ≤ ${bpsToPct(saved.maxSlippageBps)}`} />
      </div>

      <Section title="Vault">
        <div className="kv"><span>Address</span><Addr value={vault.address} full href={explorerUrl("address", vault.address, rpcUrl)} /></div>
        <div className="kv"><span>Agent</span>
          {vault.agent ? <Addr value={vault.agent} href={explorerUrl("address", vault.agent, rpcUrl)} /> : <em className="mute">none delegated</em>}
        </div>
      </Section>

      <Section title="Holdings" aside={<span className="mute sm">{balances.length} token{balances.length === 1 ? "" : "s"}</span>}>
        {balances.length === 0 ? (
          <p className="empty">Nothing deposited yet. Use the form below to add a token.</p>
        ) : (
          <ul className="holdings">
            {balances.map((b) => (
              <li key={b.mint}>
                <button type="button" className="row-btn" title="Use this token in the form below" onClick={() => setMint(b.mint)}>
                  <span className="token-dot">{(symbolFor(b.mint) ?? "?").slice(0, 1)}</span>
                  <span className="grow">
                    <strong>{symbolFor(b.mint) ?? "Unknown token"}</strong>
                    <small className="mono">{shortAddr(b.mint, 6)}</small>
                  </span>
                  <span className="amt">{b.amount}</span>
                </button>
              </li>
            ))}
          </ul>
        )}
      </Section>

      <Section title="Deposit / Withdraw">
        <div className="chips">
          {KNOWN_TOKENS.map((t) => (
            <button key={t.symbol} type="button" className={`chip ${mint.trim() === t.mint ? "on" : ""}`} onClick={() => setMint(t.mint)}>{t.symbol}</button>
          ))}
          <span className="mute sm">or paste any verified mint</span>
        </div>
        <Field label="Token mint" error={mint && !mintOk ? "That doesn't look like a Solana address." : null}>
          <input className="mono-in" placeholder="Mint address" value={mint} onChange={(e) => setMint(e.target.value)} spellCheck={false} />
        </Field>
        <Field label="Amount" error={amount && !amountOk ? "Enter a positive number." : null}
          hint={held ? `Vault holds ${held.amount}` : undefined}>
          <div className="with-btn">
            <input inputMode="decimal" placeholder="0.5" value={amount} onChange={(e) => setAmount(e.target.value)} />
            {held && <button type="button" className="ghost" onClick={() => setAmount(held.amount)}>Max</button>}
          </div>
        </Field>
        <div className="row">
          <button disabled={busy || !mintOk || !amountOk} onClick={() => p.onDeposit(mint.trim(), amount)}>Deposit</button>
          <button className="secondary" disabled={busy || !mintOk || !amountOk} onClick={() => p.onWithdraw(mint.trim(), amount)}>Withdraw</button>
        </div>
      </Section>

      <Section title="Agent">
        <p className="help">The agent can act inside your guardrails but can never withdraw funds. Only you can withdraw, and only to your own wallet.</p>
        <Field label={vault.agent ? "Replace agent" : "Agent public key"} error={agentStr && !agentOk ? "That doesn't look like a Solana address." : null}>
          <input className="mono-in" placeholder="Agent public key" value={agentStr} onChange={(e) => setAgentStr(e.target.value)} spellCheck={false} />
        </Field>
        <div className="row">
          <button disabled={busy || !agentOk} onClick={() => { p.onSetAgent(agentStr.trim()); setAgentStr(""); }}>{vault.agent ? "Replace agent" : "Set agent"}</button>
          {vault.agent && !confirmRevoke && <button className="danger-outline" disabled={busy} onClick={() => setConfirmRevoke(true)}>Revoke agent…</button>}
          {vault.agent && confirmRevoke && (
            <>
              <button className="danger" disabled={busy} onClick={() => { setConfirmRevoke(false); p.onRevoke(); }}>Confirm revoke</button>
              <button className="ghost" onClick={() => setConfirmRevoke(false)}>Cancel</button>
            </>
          )}
        </div>
      </Section>

      <Section title="Guardrails" aside={dirty ? <Badge tone="warn">Unsaved changes</Badge> : undefined}>
        <div className={`killswitch ${draft.paused ? "on" : ""}`}>
          <div>
            <strong>{saved.paused ? "Vault is paused" : "Emergency pause"}</strong>
            <small>{saved.paused ? "Resume to let the agent act again." : "Instantly blocks every agent action. Your funds stay put."}</small>
          </div>
          <button className={saved.paused ? "" : "danger"} disabled={busy}
            onClick={() => p.onSaveGuardrails({ ...saved, paused: !saved.paused })}>
            {saved.paused ? "Resume" : "Pause now"}
          </button>
        </div>

        {GUARDRAIL_FIELDS.map((f) => (
          <Field key={f.key} label={<><span>{f.label}</span><b className="val">{f.show(draft[f.key])}</b></>} hint={f.help} error={errs[f.key]}>
            <div className="slider">
              <input type="range" min={f.min} max={f.max} step={f.step} value={Number.isFinite(draft[f.key]) ? draft[f.key] : f.min}
                onChange={(e) => setDraft({ ...draft, [f.key]: Number(e.target.value) })} />
              <input type="number" min={f.min} max={f.max} value={Number.isFinite(draft[f.key]) ? draft[f.key] : ""}
                onChange={(e) => setDraft({ ...draft, [f.key]: e.target.value === "" ? NaN : Number(e.target.value) })} />
            </div>
          </Field>
        ))}

        <div className="row">
          <button disabled={busy || !dirty || invalid} onClick={() => p.onSaveGuardrails(draft)}>Save guardrails</button>
          {dirty && <button className="ghost" onClick={() => setDraft(saved)}>Discard</button>}
        </div>
      </Section>
    </>
  );
}

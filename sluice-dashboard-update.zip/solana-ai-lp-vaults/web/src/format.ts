// Pure helpers (no Solana imports) so they are easy to test and preview.

export const KNOWN_TOKENS = [
  { symbol: "SOL", mint: "So11111111111111111111111111111111111111112" },
  { symbol: "USDC", mint: "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v" },
];

export const symbolFor = (mint: string) => KNOWN_TOKENS.find((t) => t.mint === mint)?.symbol;

export const shortAddr = (a: string, n = 4) => (a.length <= n * 2 + 1 ? a : `${a.slice(0, n)}…${a.slice(-n)}`);

export const bpsToPct = (bps: number) => `${(bps / 100).toFixed(bps % 100 === 0 ? 0 : 2)}%`;

export type Cluster = "devnet" | "mainnet" | "custom";

export function clusterOf(rpcUrl: string): Cluster {
  if (/devnet/i.test(rpcUrl)) return "devnet";
  if (/mainnet/i.test(rpcUrl)) return "mainnet";
  return "custom";
}

export function explorerUrl(kind: "tx" | "address", id: string, rpcUrl: string) {
  const c = clusterOf(rpcUrl);
  const q = c === "mainnet" ? "" : c === "devnet" ? "?cluster=devnet" : `?cluster=custom&customUrl=${encodeURIComponent(rpcUrl)}`;
  return `https://explorer.solana.com/${kind}/${id}${q}`;
}

/** Parse a decimal string to base units. Returns null when invalid. */
export function parseUnits(input: string, decimals: number): bigint | null {
  const s = input.trim();
  if (!/^\d*\.?\d*$/.test(s) || s === "" || s === ".") return null;
  const [whole, frac = ""] = s.split(".");
  if (frac.length > decimals) return null;
  return BigInt(whole || "0") * 10n ** BigInt(decimals) + BigInt((frac + "0".repeat(decimals)).slice(0, decimals) || "0");
}

export interface GuardrailValues {
  maxPositionBps: number;
  maxSlippageBps: number;
  dailyActionCap: number;
  stopLossBps: number;
  paused: boolean;
}

/** Mirrors the on-chain checks in `set_guardrails`. */
export const GUARDRAIL_FIELDS = [
  { key: "maxPositionBps", label: "Max position size", help: "Largest share of the vault the agent may put into one position.", min: 1, max: 10000, step: 100, show: bpsToPct },
  { key: "maxSlippageBps", label: "Max slippage", help: "Worst price movement the agent may accept on a trade (program cap 5%).", min: 0, max: 500, step: 5, show: bpsToPct },
  { key: "stopLossBps", label: "Stop-loss", help: "Drawdown that triggers the agent to exit a position.", min: 0, max: 10000, step: 100, show: bpsToPct },
  { key: "dailyActionCap", label: "Daily action cap", help: "Maximum agent actions per 24 hours.", min: 1, max: 255, step: 1, show: (n: number) => `${n} / day` },
] as const;

export function validateGuardrails(g: GuardrailValues): Partial<Record<keyof GuardrailValues, string>> {
  const errs: Partial<Record<keyof GuardrailValues, string>> = {};
  for (const f of GUARDRAIL_FIELDS) {
    const v = g[f.key];
    if (!Number.isInteger(v) || v < f.min || v > f.max) errs[f.key] = `Must be a whole number from ${f.min} to ${f.max}.`;
  }
  return errs;
}

export const isPubkeyLike = (s: string) => /^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(s.trim());

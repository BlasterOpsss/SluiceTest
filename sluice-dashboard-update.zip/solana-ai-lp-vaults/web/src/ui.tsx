import { useState, type ReactNode } from "react";
import { shortAddr } from "./format";

export function CopyButton({ text, label = "Copy" }: { text: string; label?: string }) {
  const [done, setDone] = useState(false);
  return (
    <button
      type="button"
      className="ghost sm"
      onClick={async () => {
        try { await navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 1200); } catch { /* clipboard blocked */ }
      }}
    >
      {done ? "Copied" : label}
    </button>
  );
}

export function Addr({ value, href, full }: { value: string; href?: string; full?: boolean }) {
  return (
    <span className="addr">
      <code title={value}>{full ? value : shortAddr(value, 6)}</code>
      <CopyButton text={value} />
      {href && <a className="ghost sm btn" href={href} target="_blank" rel="noreferrer">Explorer ↗</a>}
    </span>
  );
}

export type Tone = "ok" | "warn" | "bad" | "mute";
export const Badge = ({ tone, children }: { tone: Tone; children: ReactNode }) => (
  <span className={`badge ${tone}`}><i />{children}</span>
);

export const Stat = ({ label, value, sub, tone }: { label: string; value: ReactNode; sub?: ReactNode; tone?: Tone }) => (
  <div className="stat">
    <span className="stat-label">{label}</span>
    <span className={`stat-value ${tone ?? ""}`}>{value}</span>
    {sub && <span className="stat-sub">{sub}</span>}
  </div>
);

export const Section = ({ title, aside, children }: { title: string; aside?: ReactNode; children: ReactNode }) => (
  <section>
    <div className="section-head"><h2>{title}</h2>{aside}</div>
    {children}
  </section>
);

export const Field = ({ label, hint, error, children }: { label: ReactNode; hint?: ReactNode; error?: string | null; children: ReactNode }) => (
  <label className="field">
    <span className="field-label">{label}</span>
    {children}
    {error ? <span className="field-error">{error}</span> : hint ? <span className="field-hint">{hint}</span> : null}
  </label>
);

export interface ToastItem { id: number; kind: "info" | "ok" | "err"; text: string; href?: string }

export function Toasts({ items, onClose }: { items: ToastItem[]; onClose: (id: number) => void }) {
  return (
    <div className="toasts" role="status" aria-live="polite">
      {items.map((t) => (
        <div key={t.id} className={`toast ${t.kind}`}>
          <span>{t.text}{t.href && <> · <a href={t.href} target="_blank" rel="noreferrer">View tx ↗</a></>}</span>
          <button className="ghost sm" aria-label="Dismiss" onClick={() => onClose(t.id)}>✕</button>
        </div>
      ))}
    </div>
  );
}

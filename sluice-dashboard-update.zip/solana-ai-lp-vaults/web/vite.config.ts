import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  define: { global: "globalThis" },
  // host: true lets GitHub Codespaces forward the port to your browser.
  server: { host: true, port: 5173, strictPort: true },
  preview: { host: true, port: 4173 },
});
